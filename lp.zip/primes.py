def factors(n):
    return n